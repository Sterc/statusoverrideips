# Changelog for StatusOverrideIPs

### 1.0.0 pl2 (2013-07-22)
=============
- UI fixes
- Added help button (opens github README)

### 1.0.0 pl (2013-07-16)
=============
- Initial release