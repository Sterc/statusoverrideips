<?php
namespace Sterc\StatusOverrideIps\Model;

use xPDO\xPDO;

/**
 * Class SoIP
 *
 * @property string $name
 * @property string $ip
 *
 * @package Sterc\StatusOverrideIps\Model
 */
class SoIP extends \xPDO\Om\xPDOSimpleObject
{
}
