<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'Sterc\\StatusOverrideIps\\Model',
    'namespacePrefix' => 'Sterc\\StatusOverrideIps',
    'class_map' => 
    array (
        'xPDO\\Om\\xPDOSimpleObject' => 
        array (
            0 => 'Sterc\\StatusOverrideIps\\Model\\SoIP',
        ),
    ),
);